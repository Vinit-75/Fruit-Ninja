var PLAY = 1;
var END = 0;
var gameState = PLAY;
var fruit, fruit_image, fruit2, fruit2_image, fruit3, fruit3_image, fruit4, fruit4_image;
var monster1, monster1_image, monster2, monster2_image;
var sword, sword_image;
var gameover, gameover_image;
var score;

function preload() {

  sword_image = loadImage("sword.png");
  fruit1 = loadImage("fruit1.png");
  fruit2 = loadImage("fruit2.png");
  fruit3 = loadImage("fruit3.png");
  fruit4 = loadImage("fruit4.png");
  monster1 = loadAnimation("alien1.png", "alien2.png");
  gameover_image = loadImage("gameover.png");
}

function setup() {
  createCanvas(400, 400)

  sword = createSprite(40, 200, 20, 20);
  sword.addImage("sword", sword_image);
  sword.scale = 0.5;
   
  gameover = createSprite(200,200,20,20);
  gameover.addImage("gameover",gameover_image);
   
  score = 0;

  fruitGroup = createGroup();
  enemyGroup = createGroup();

  gameover.x = sword.x;
  gameover.y = sword.y;
}

function draw() {

  background("lightgreen");

  //moving the sword using mouse
  sword.y = mouseY;
  sword.x = mouseX;

  if (gameState === PLAY) {

    fruits();
    Enemy();
    gameover.visible = false;
    
  }

  if(gameState === END){
    
    sword.visible= false;
    fruitGroup.destroyEach();
    enemyGroup.destroyEach();
    score = 0;
    gameover.visble = true;
    
  } 
  
  
   
  
   
  if(sword.isTouching(fruitGroup)){
    fruit.destroy();
    score = score +1;
    
  }
  
  if(sword.isTouching(enemyGroup)){
    gameState = END;
    
  } 
 

  drawSprites();


  text("score: "+ score, 200, 50);

}

function fruits() {
  if (World.frameCount % 80 === 0) {
    fruit = createSprite(400, 200, 20, 20);
    fruit.scale = 0.2;
    r = Math.round(random(1, 4))
    if (r == 1) {
      fruit.addImage("fruit1", fruit1);
    } else if (r == 2) {
      fruit.addImage("fruit2",fruit2);
    } else if (r == 3) {
      fruit.addImage("fruit3",fruit3);
    } else {
      fruit.addImage("fruit4",fruit4);
    }

    fruit.y = Math.round(random(50, 340));

    fruit.velocityX = -7;
    fruit.setLifetime = 100;

    fruitGroup.add(fruit);

  }
}

function Enemy() {
  if (World.frameCount % 200 === 0) {
    monster = createSprite(400, 200, 20, 20);
    monster.addAnimation("moving", monster1);
    monster.y = Math.round(random(100, 300));
    monster.velocityX = -8;
    monster.setLifetime = 50;
    enemyGroup.add(monster);
  }
}